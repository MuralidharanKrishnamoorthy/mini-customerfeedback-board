import React, { useEffect, useState } from 'react';
import { getFeedbacks, updateStatus, deleteFeedback } from '../services/feedbackApi';
import { useNavigate } from 'react-router-dom';

const Admin = () => {
  const [feedbacks, setFeedbacks] = useState([]);
  const navigate = useNavigate();

  const styles = {
    container: {
      maxWidth: '1024px',
      margin: '32px auto 0',
      padding: '0 16px'
    },
    title: {
      fontSize: '24px',
      fontWeight: 'bold',
      marginBottom: '24px',
      color: '#1f2937'
    },
    feedbackCard: {
      backgroundColor: '#f3f4f6',
      padding: '16px',
      marginBottom: '16px',
      borderRadius: '4px',
      boxShadow: '0 1px 3px rgba(0, 0, 0, 0.1)'
    },
    feedbackTitle: {
      fontWeight: '600',
      fontSize: '18px',
      color: '#1f2937',
      marginBottom: '8px'
    },
    feedbackDescription: {
      fontSize: '14px',
      color: '#374151',
      marginBottom: '8px'
    },
    controlsContainer: {
      display: 'flex',
      alignItems: 'center',
      gap: '12px'
    },
    select: {
      border: '1px solid #d1d5db',
      padding: '4px 8px',
      borderRadius: '4px',
      fontSize: '14px'
    },
    deleteButton: {
      color: '#ef4444',
      marginLeft: 'auto',
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      fontSize: '14px',
      textDecoration: 'none'
    },
    deleteButtonHover: {
      textDecoration: 'underline'
    }
  };

  const fetchFeedbacks = async () => {
    const res = await getFeedbacks();
    setFeedbacks(res.data);
  };

  const handleStatusChange = async (id, status) => {
    await updateStatus(id, status);
    fetchFeedbacks();
  };

  const handleDelete = async (id) => {
    if (window.confirm("Are you sure you want to delete this feedback?")) {
      await deleteFeedback(id);
      fetchFeedbacks();
    }
  };

  useEffect(() => {
    const role = localStorage.getItem("role");
    if (role !== "admin") {
      navigate("/login");
    } else {
      fetchFeedbacks();
    }
  }, []);

  return (
    <div style={styles.container}>
      <h2 style={styles.title}>Admin Dashboard</h2>
      {feedbacks.map(fb => (
        <div key={fb._id} style={styles.feedbackCard}>
          <h3 style={styles.feedbackTitle}>{fb.title}</h3>
          <p style={styles.feedbackDescription}>{fb.description}</p>
          <div style={styles.controlsContainer}>
            <select
              value={fb.status}
              onChange={(e) => handleStatusChange(fb._id, e.target.value)}
              style={styles.select}
            >
              <option>Open</option>
              <option>Planned</option>
              <option>In Progress</option>
              <option>Done</option>
            </select>
            <button
              style={styles.deleteButton}
              onMouseEnter={(e) => e.target.style.textDecoration = 'underline'}
              onMouseLeave={(e) => e.target.style.textDecoration = 'none'}
              onClick={() => handleDelete(fb._id)}
            >
              Delete
            </button>
          </div>
        </div>
      ))}
    </div>
  );
};

export default Admin;
