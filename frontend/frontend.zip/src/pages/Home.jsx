"use client"

import { useEffect, useState } from "react"
import FeedbackCard from "../components/FeedbackCard"
import { getFeedbacks, upvoteFeedback } from "../services/feedbackApi"
import Navbar from "../components/Navbar"
import FilterBar from "../components/FilterBar"

const Home = () => {
  const [feedbacks, setFeedbacks] = useState([])
  const [loading, setLoading] = useState(true)
  const [statusFilter, setStatusFilter] = useState("")
  const [categoryFilter, setCategoryFilter] = useState("")
  const [sort, setSort] = useState("latest")
  const [search, setSearch] = useState("")

  const fetchFeedbacks = async () => {
    setLoading(true)
    try {
      const params = { status: statusFilter, category: categoryFilter, sort, search }
      const res = await getFeedbacks(params)
      setFeedbacks(res.data)
    } catch (error) {
      console.error("Error fetching feedbacks:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleUpvote = async (id) => {
    try {
      await upvoteFeedback(id)
      fetchFeedbacks()
    } catch (error) {
      console.error("Error upvoting feedback:", error)
    }
  }

  useEffect(() => {
    fetchFeedbacks()
  }, [statusFilter, categoryFilter, sort, search])

  const getStatusStats = () => {
    const stats = {
      total: feedbacks.length,
      open: feedbacks.filter(f => f.status === "Open").length,
      planned: feedbacks.filter(f => f.status === "Planned").length,
      inProgress: feedbacks.filter(f => f.status === "In Progress").length,
      done: feedbacks.filter(f => f.status === "Done").length,
    }
    return stats
  }

  const stats = getStatusStats()

  return (
    <>
      <Navbar />
      <div style={styles.page}>
        <div style={styles.container}>
          {/* Hero Section */}
          <div style={styles.hero}>
            <div style={styles.badge}>⚡ Powered by community feedback</div>
            <h1 style={styles.heading}>Shape the Future <span style={styles.highlight}>Together</span></h1>
            <p style={styles.subheading}>
              Your voice matters. Share feedback, vote on features, and help us build the product you love.
            </p>
          </div>

          {/* Stats */}
          <div style={styles.statsGrid}>
            {["Total Ideas", "Open", "Planned", "In Progress", "Completed"].map((label, idx) => {
              const value = [stats.total, stats.open, stats.planned, stats.inProgress, stats.done][idx]
              return (
                <div key={label} style={styles.card}>
                  <div style={styles.cardValue}>{value}</div>
                  <div style={styles.cardLabel}>{label}</div>
                </div>
              )
            })}
          </div>

          {/* Filter Bar */}
          <FilterBar
            setStatusFilter={setStatusFilter}
            setCategoryFilter={setCategoryFilter}
            setSort={setSort}
            setSearch={setSearch}
          />

          {/* Content */}
          {loading ? (
            <div style={styles.loadingWrapper}>
              <div style={styles.spinner}></div>
              <span>Loading feedback...</span>
            </div>
          ) : feedbacks.length === 0 ? (
            <div style={styles.noFeedback}>
              <div style={styles.noFeedbackIcon}>📝</div>
              <h3 style={{ fontSize: "24px", fontWeight: "bold" }}>No feedback found</h3>
              <p style={styles.noFeedbackText}>
                {search || statusFilter || categoryFilter
                  ? "Try adjusting your filters to see more results."
                  : "Be the first to share your ideas and help shape our product!"}
              </p>
              {!search && !statusFilter && !categoryFilter && (
                <a href="/submit" style={styles.button}>
                  ➕ Share Your First Idea
                </a>
              )}
            </div>
          ) : (
            <div>
              {feedbacks.map((fb, index) => (
                <div key={fb._id} style={{ animationDelay: `${index * 0.1}s` }}>
                  <FeedbackCard feedback={fb} onUpvote={handleUpvote} />
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Internal CSS */}
      <style>{`
        @keyframes spin {
          to { transform: rotate(360deg); }
        }
      `}</style>
    </>
  )
}

const styles = {
  page: {
    minHeight: "100vh",
    background: "linear-gradient(to bottom right, #f9fafb, #ffffff)",
  },
  container: {
    maxWidth: "1200px",
    margin: "0 auto",
    padding: "3rem 1.5rem",
  },
  hero: {
    textAlign: "center",
    marginBottom: "4rem",
  },
  badge: {
    display: "inline-block",
    padding: "0.5rem 1rem",
    backgroundColor: "#e0f2fe",
    color: "#0284c7",
    borderRadius: "9999px",
    fontSize: "0.875rem",
    marginBottom: "1rem",
  },
  heading: {
    fontSize: "3rem",
    fontWeight: "bold",
    color: "#111827",
    marginBottom: "1rem",
  },
  highlight: {
    display: "block",
    background: "linear-gradient(to right, #3b82f6, #8b5cf6)",
    WebkitBackgroundClip: "text",
    color: "transparent",
  },
  subheading: {
    fontSize: "1.25rem",
    color: "#4b5563",
    maxWidth: "700px",
    margin: "0 auto",
  },
  statsGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(140px, 1fr))",
    gap: "1rem",
    marginBottom: "3rem",
  },
  card: {
    background: "#fff",
    padding: "1.5rem",
    textAlign: "center",
    borderRadius: "12px",
    boxShadow: "0 2px 8px rgba(0,0,0,0.05)",
    transition: "transform 0.3s ease",
  },
  cardValue: {
    fontSize: "2rem",
    fontWeight: "bold",
    marginBottom: "0.5rem",
  },
  cardLabel: {
    fontSize: "0.875rem",
    color: "#6b7280",
    textTransform: "uppercase",
  },
  loadingWrapper: {
    textAlign: "center",
    padding: "4rem 0",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "column",
    gap: "1rem",
  },
  spinner: {
    width: "40px",
    height: "40px",
    border: "3px solid #3b82f6",
    borderTopColor: "transparent",
    borderRadius: "50%",
    animation: "spin 1s linear infinite",
  },
  noFeedback: {
    textAlign: "center",
    padding: "4rem 1rem",
  },
  noFeedbackIcon: {
    fontSize: "3rem",
    marginBottom: "1rem",
  },
  noFeedbackText: {
    fontSize: "1.125rem",
    color: "#6b7280",
    margin: "1rem 0",
    maxWidth: "400px",
    marginInline: "auto",
  },
  button: {
    display: "inline-block",
    padding: "0.75rem 1.25rem",
    fontSize: "1rem",
    backgroundColor: "#3b82f6",
    color: "white",
    borderRadius: "0.5rem",
    textDecoration: "none",
    marginTop: "1rem",
  },
}

export default Home