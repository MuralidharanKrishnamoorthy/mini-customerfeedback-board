// src/pages/Detail.jsx
import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  getFeedbackById,
  upvoteFeedback,
  updateStatus,
  postComment,
} from '../services/feedbackApi';
import Navbar from '../components/Navbar';

const Detail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [feedback, setFeedback] = useState(null);
  const [comment, setComment] = useState("");
  const [isSubmittingComment, setIsSubmittingComment] = useState(false);
  const [loading, setLoading] = useState(true);

  const user = JSON.parse(localStorage.getItem("user"));

  const styles = {
    container: {
      minHeight: '100vh',
      backgroundColor: '#f9fafb',
      paddingTop: '2rem',
      paddingBottom: '2rem'
    },
    maxWidth: {
      maxWidth: '56rem',
      margin: '0 auto',
      padding: '0 1rem'
    },
    loadingContainer: {
      minHeight: '100vh',
      backgroundColor: '#f9fafb',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    },
    loadingContent: {
      display: 'flex',
      alignItems: 'center',
      gap: '0.5rem'
    },
    spinner: {
      width: '1.5rem',
      height: '1.5rem',
      border: '2px solid #2563eb',
      borderTop: '2px solid transparent',
      borderRadius: '50%',
      animation: 'spin 1s linear infinite'
    },
    loadingText: {
      color: '#6b7280'
    },
    notFoundContainer: {
      minHeight: '100vh',
      backgroundColor: '#f9fafb',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    },
    notFoundContent: {
      textAlign: 'center'
    },
    notFoundTitle: {
      fontSize: '1.5rem',
      fontWeight: 'bold',
      color: '#111827',
      marginBottom: '0.5rem'
    },
    notFoundText: {
      color: '#6b7280',
      marginBottom: '1rem'
    },
    backButton: {
      display: 'flex',
      alignItems: 'center',
      color: '#6b7280',
      marginBottom: '1.5rem',
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      fontSize: '1rem',
      transition: 'color 0.2s'
    },
    card: {
      backgroundColor: 'white',
      borderRadius: '0.75rem',
      boxShadow: '0 1px 3px 0 rgba(0, 0, 0, 0.1)',
      border: '1px solid #e5e7eb',
      overflow: 'hidden'
    },
    header: {
      padding: '2rem',
      borderBottom: '1px solid #e5e7eb'
    },
    headerContent: {
      display: 'flex',
      alignItems: 'flex-start',
      justifyContent: 'space-between',
      marginBottom: '1rem'
    },
    headerLeft: {
      flex: 1
    },
    tags: {
      display: 'flex',
      alignItems: 'center',
      gap: '0.5rem',
      marginBottom: '1rem'
    },
    tag: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: '0.25rem',
      padding: '0.25rem 0.625rem',
      borderRadius: '0.375rem',
      fontSize: '0.75rem',
      fontWeight: '500',
      border: '1px solid'
    },
    tagBug: {
      backgroundColor: '#fef2f2',
      color: '#dc2626',
      borderColor: '#fecaca'
    },
    tagFeature: {
      backgroundColor: '#eef2ff',
      color: '#4f46e5',
      borderColor: '#c7d2fe'
    },
    tagUI: {
      backgroundColor: '#fdf2f8',
      color: '#db2777',
      borderColor: '#fbcfe8'
    },
    tagOpen: {
      backgroundColor: '#fff7ed',
      color: '#c2410c',
      borderColor: '#fed7aa'
    },
    tagPlanned: {
      backgroundColor: '#eff6ff',
      color: '#1d4ed8',
      borderColor: '#bfdbfe'
    },
    tagInProgress: {
      backgroundColor: '#f3e8ff',
      color: '#7c3aed',
      borderColor: '#d8b4fe'
    },
    tagDone: {
      backgroundColor: '#f0fdf4',
      color: '#16a34a',
      borderColor: '#bbf7d0'
    },
    title: {
      fontSize: '1.5rem',
      fontWeight: 'bold',
      color: '#111827',
      marginBottom: '1rem'
    },
    metaInfo: {
      display: 'flex',
      alignItems: 'center',
      fontSize: '0.875rem',
      color: '#6b7280',
      gap: '1rem'
    },
    upvoteButton: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      minWidth: '4rem',
      padding: '0.75rem 1rem',
      backgroundColor: '#f9fafb',
      border: '1px solid #e5e7eb',
      borderRadius: '0.5rem',
      cursor: 'pointer',
      transition: 'all 0.2s',
      marginLeft: '1.5rem'
    },
    upvoteIcon: {
      width: '1.25rem',
      height: '1.25rem',
      marginBottom: '0.25rem',
      color: '#6b7280',
      transition: 'color 0.2s'
    },
    upvoteCount: {
      fontSize: '0.875rem',
      fontWeight: '600',
      color: '#374151',
      transition: 'color 0.2s'
    },
    adminPanel: {
      backgroundColor: '#eff6ff',
      border: '1px solid #bfdbfe',
      borderRadius: '0.5rem',
      padding: '1rem'
    },
    adminContent: {
      display: 'flex',
      alignItems: 'center',
      gap: '0.75rem'
    },
    adminIcon: {
      width: '1.25rem',
      height: '1.25rem',
      color: '#2563eb'
    },
    adminLabel: {
      fontSize: '0.875rem',
      fontWeight: '500',
      color: '#1e3a8a'
    },
    select: {
      border: '1px solid #93c5fd',
      borderRadius: '0.375rem',
      padding: '0.25rem 0.75rem',
      fontSize: '0.875rem'
    },
    section: {
      padding: '2rem',
      borderBottom: '1px solid #e5e7eb'
    },
    sectionTitle: {
      fontSize: '1.125rem',
      fontWeight: '600',
      color: '#111827',
      marginBottom: '0.75rem'
    },
    description: {
      color: '#374151',
      lineHeight: '1.6',
      whiteSpace: 'pre-wrap'
    },
    commentsSection: {
      padding: '2rem'
    },
    commentsHeader: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      marginBottom: '1.5rem'
    },
    commentsList: {
      display: 'flex',
      flexDirection: 'column',
      gap: '1rem',
      marginBottom: '2rem'
    },
    comment: {
      backgroundColor: '#f9fafb',
      borderRadius: '0.5rem',
      padding: '1rem',
      border: '1px solid #e5e7eb'
    },
    commentHeader: {
      display: 'flex',
      alignItems: 'center',
      marginBottom: '0.5rem'
    },
    avatar: {
      width: '2rem',
      height: '2rem',
      backgroundColor: '#dbeafe',
      borderRadius: '50%',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      marginRight: '0.75rem'
    },
    avatarText: {
      fontSize: '0.875rem',
      fontWeight: '500',
      color: '#2563eb'
    },
    commentAuthor: {
      fontWeight: '500',
      color: '#111827'
    },
    commentDate: {
      fontSize: '0.75rem',
      color: '#6b7280'
    },
    commentText: {
      color: '#374151',
      marginLeft: '2.75rem',
      whiteSpace: 'pre-wrap'
    },
    noComments: {
      textAlign: 'center',
      padding: '2rem 0',
      color: '#6b7280'
    },
    noCommentsIcon: {
      width: '3rem',
      height: '3rem',
      margin: '0 auto 1rem',
      color: '#d1d5db'
    },
    addCommentForm: {
      borderTop: '1px solid #e5e7eb',
      paddingTop: '1.5rem'
    },
    commentInputContainer: {
      display: 'flex',
      alignItems: 'flex-start',
      gap: '0.75rem'
    },
    commentInput: {
      flex: 1
    },
    textarea: {
      display: 'block',
      width: '100%',
      padding: '0.5rem 0.75rem',
      border: '1px solid #d1d5db',
      borderRadius: '0.5rem',
      resize: 'vertical',
      fontSize: '0.875rem'
    },
    commentActions: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      marginTop: '0.75rem'
    },
    commentingAs: {
      fontSize: '0.75rem',
      color: '#6b7280'
    },
    submitButton: {
      padding: '0.5rem 1rem',
      borderRadius: '0.5rem',
      fontSize: '0.875rem',
      fontWeight: '500',
      border: 'none',
      cursor: 'pointer',
      transition: 'all 0.2s'
    },
    submitButtonActive: {
      backgroundColor: '#2563eb',
      color: 'white'
    },
    submitButtonDisabled: {
      backgroundColor: '#d1d5db',
      color: '#6b7280',
      cursor: 'not-allowed'
    },
    signInPrompt: {
      borderTop: '1px solid #e5e7eb',
      paddingTop: '1.5rem',
      textAlign: 'center'
    },
    signInText: {
      color: '#6b7280',
      marginBottom: '1rem'
    },
    signInButton: {
      backgroundColor: '#2563eb',
      color: 'white',
      padding: '0.5rem 1rem',
      borderRadius: '0.5rem',
      border: 'none',
      cursor: 'pointer',
      transition: 'background-color 0.2s'
    }
  };

  const statusColors = {
    Open: styles.tagOpen,
    Planned: styles.tagPlanned,
    'In Progress': styles.tagInProgress,
    Done: styles.tagDone,
  };

  const categoryColors = {
    Bug: styles.tagBug,
    Feature: styles.tagFeature,
    UI: styles.tagUI,
  };

  const statusIcons = {
    Open: "🔵",
    Planned: "📋",
    'In Progress': "⚡",
    Done: "✅",
  };

  const categoryIcons = {
    Bug: "🐛",
    Feature: "✨",
    UI: "🎨",
  };

  const fetchFeedback = async () => {
    try {
      const res = await getFeedbackById(id);
      setFeedback(res.data);
    } catch (error) {
      console.error('Error fetching feedback:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleUpvote = async () => {
    try {
      await upvoteFeedback(id);
      fetchFeedback();
    } catch (error) {
      console.error('Error upvoting feedback:', error);
    }
  };

  const handleStatusChange = async (e) => {
    try {
      await updateStatus(id, e.target.value);
      fetchFeedback();
    } catch (error) {
      console.error('Error updating status:', error);
    }
  };

  const handleCommentSubmit = async () => {
    if (!user || !user.userId) {
      alert("Login required to comment.");
      return;
    }
    if (!comment.trim()) {
      alert("Comment cannot be empty.");
      return;
    }

    setIsSubmittingComment(true);
    try {
      await postComment(id, {
        userId: user.userId,
        text: comment.trim(),
        author: user.username,
      });
      setComment("");
      fetchFeedback();
    } catch (error) {
      console.error('Error posting comment:', error);
      alert('Failed to post comment. Please try again.');
    } finally {
      setIsSubmittingComment(false);
    }
  };

  useEffect(() => {
    fetchFeedback();
  }, [id]);

  if (loading) {
    return (
      <>
        <style>
          {`
            @keyframes spin {
              from { transform: rotate(0deg); }
              to { transform: rotate(360deg); }
            }
          `}
        </style>
        <Navbar />
        <div style={styles.loadingContainer}>
          <div style={styles.loadingContent}>
            <div style={styles.spinner}></div>
            <span style={styles.loadingText}>Loading feedback...</span>
          </div>
        </div>
      </>
    );
  }

  if (!feedback) {
    return (
      <>
        <Navbar />
        <div style={styles.notFoundContainer}>
          <div style={styles.notFoundContent}>
            <h2 style={styles.notFoundTitle}>Feedback not found</h2>
            <p style={styles.notFoundText}>The feedback you're looking for doesn't exist.</p>
            <button
              onClick={() => navigate('/')}
              style={{...styles.signInButton, display: 'inline-block'}}
              onMouseOver={(e) => e.target.style.backgroundColor = '#1d4ed8'}
              onMouseOut={(e) => e.target.style.backgroundColor = '#2563eb'}
            >
              Back to Home
            </button>
          </div>
        </div>
      </>
    );
  }

  const statusClass = statusColors[feedback.status] || styles.tagOpen;
  const categoryClass = categoryColors[feedback.category] || styles.tagOpen;

  return (
    <>
      <style>
        {`
          @keyframes spin {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
          }
          .upvote-button:hover {
            background-color: #eff6ff !important;
            border-color: #93c5fd !important;
          }
          .upvote-button:hover .upvote-icon {
            color: #2563eb !important;
          }
          .upvote-button:hover .upvote-count {
            color: #2563eb !important;
          }
          .back-button:hover {
            color: #111827 !important;
          }
          .submit-button:hover:not(:disabled) {
            background-color: #1d4ed8 !important;
          }
          .sign-in-button:hover {
            background-color: #1d4ed8 !important;
          }
          .textarea:focus, .select:focus {
            outline: none;
            border-color: #3b82f6;
            box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.2);
          }
        `}
      </style>
      <Navbar />
      <div style={styles.container}>
        <div style={styles.maxWidth}>
          <button
            onClick={() => navigate(-1)}
            style={styles.backButton}
            className="back-button"
          >
            <svg style={{width: '1.25rem', height: '1.25rem', marginRight: '0.5rem'}} fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
            Back to feedback
          </button>

          <div style={styles.card}>
            <div style={styles.header}>
              <div style={styles.headerContent}>
                <div style={styles.headerLeft}>
                  <div style={styles.tags}>
                    <span style={{...styles.tag, ...categoryClass}}>
                      <span style={{fontSize: '0.875rem'}}>{categoryIcons[feedback.category]}</span>
                      {feedback.category}
                    </span>
                    <span style={{...styles.tag, ...statusClass}}>
                      <span style={{fontSize: '0.875rem'}}>{statusIcons[feedback.status]}</span>
                      {feedback.status}
                    </span>
                  </div>

                  <h1 style={styles.title}>
                    {feedback.title}
                  </h1>

                  <div style={styles.metaInfo}>
                    <span>ID: #{feedback._id.slice(-6)}</span>
                    <span>•</span>
                    <span>{new Date(feedback.createdAt).toLocaleDateString()}</span>
                  </div>
                </div>

                <div>
                  <button
                    onClick={handleUpvote}
                    style={styles.upvoteButton}
                    className="upvote-button"
                  >
                    <svg style={styles.upvoteIcon} className="upvote-icon" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M3.293 9.707a1 1 0 010-1.414l6-6a1 1 0 011.414 0l6 6a1 1 0 01-1.414 1.414L11 5.414V17a1 1 0 11-2 0V5.414L4.707 9.707a1 1 0 01-1.414 0z" clipRule="evenodd" />
                    </svg>
                    <span style={styles.upvoteCount} className="upvote-count">
                      {feedback.upvotes}
                    </span>
                  </button>
                </div>
              </div>

              {user?.role === "admin" && (
                <div style={styles.adminPanel}>
                  <div style={styles.adminContent}>
                    <svg style={styles.adminIcon} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                    </svg>
                    <label style={styles.adminLabel}>Admin: Update Status</label>
                    <select
                      value={feedback.status}
                      onChange={handleStatusChange}
                      style={styles.select}
                      className="select"
                    >
                      <option value="Open">Open</option>
                      <option value="Planned">Planned</option>
                      <option value="In Progress">In Progress</option>
                      <option value="Done">Done</option>
                    </select>
                  </div>
                </div>
              )}
            </div>

            <div style={styles.section}>
              <h2 style={styles.sectionTitle}>Description</h2>
              <div>
                <p style={styles.description}>
                  {feedback.description}
                </p>
              </div>
            </div>

            <div style={styles.commentsSection}>
              <div style={styles.commentsHeader}>
                <h2 style={styles.sectionTitle}>
                  Comments ({feedback.comments?.length || 0})
                </h2>
              </div>

              <div style={styles.commentsList}>
                {feedback.comments?.length > 0 ? (
                  feedback.comments.map((c, i) => (
                    <div key={i} style={styles.comment}>
                      <div style={styles.commentHeader}>
                        <div style={styles.avatar}>
                          <span style={styles.avatarText}>
                            {c.author?.charAt(0).toUpperCase()}
                          </span>
                        </div>
                        <div>
                          <p style={styles.commentAuthor}>{c.author}</p>
                          <p style={styles.commentDate}>
                            {new Date(c.createdAt).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                      <p style={styles.commentText}>{c.text}</p>
                    </div>
                  ))
                ) : (
                  <div style={styles.noComments}>
                    <svg style={styles.noCommentsIcon} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                    </svg>
                    <p>No comments yet. Be the first to comment!</p>
                  </div>
                )}
              </div>

              {user ? (
                <div style={styles.addCommentForm}>
                  <div style={styles.commentInputContainer}>
                    <div style={styles.avatar}>
                      <span style={styles.avatarText}>
                        {user.username?.charAt(0).toUpperCase()}
                      </span>
                    </div>
                    <div style={styles.commentInput}>
                      <textarea
                        value={comment}
                        onChange={(e) => setComment(e.target.value)}
                        placeholder="Add a comment..."
                        style={styles.textarea}
                        className="textarea"
                        rows={3}
                      />
                      <div style={styles.commentActions}>
                        <p style={styles.commentingAs}>
                          Commenting as {user.username}
                        </p>
                        <button
                          onClick={handleCommentSubmit}
                          disabled={isSubmittingComment || !comment.trim()}
                          style={{
                            ...styles.submitButton,
                            ...(isSubmittingComment || !comment.trim() 
                              ? styles.submitButtonDisabled 
                              : styles.submitButtonActive
                            )
                          }}
                          className="submit-button"
                        >
                          {isSubmittingComment ? 'Posting...' : 'Post Comment'}
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div style={styles.signInPrompt}>
                  <p style={styles.signInText}>Sign in to join the conversation</p>
                  <button
                    onClick={() => navigate('/login')}
                    style={styles.signInButton}
                    className="sign-in-button"
                  >
                    Sign In
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Detail;