// src/pages/Submit.jsx
import React, { useState } from 'react';
import { postFeedback } from '../services/feedbackApi';
import { useNavigate } from 'react-router-dom';
import Navbar from '../components/Navbar';

const Submit = () => {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    category: 'Feature',
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const navigate = useNavigate();

  const user = JSON.parse(localStorage.getItem("user"));

  const handleChange = (e) =>
    setFormData({ ...formData, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!user || !user.userId) {
      alert("You must be logged in to submit feedback.");
      return;
    }

    if (!formData.title.trim() || !formData.description.trim()) {
      alert('Please fill all required fields.');
      return;
    }

    setIsSubmitting(true);
    try {
      await postFeedback({ ...formData, userId: user.userId });
      navigate('/');
    } catch (error) {
      console.error('Error submitting feedback:', error);
      alert('Failed to submit feedback. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const categoryOptions = [
    { value: 'Feature', label: '✨ Feature Request', description: 'Suggest a new feature or enhancement' },
    { value: 'Bug', label: '🐛 Bug Report', description: 'Report a problem or issue you encountered' },
    { value: 'UI', label: '🎨 UI/UX Improvement', description: 'Suggest improvements to user interface' },
  ];

  const styles = {
    container: {
      minHeight: '100vh',
      backgroundColor: '#f9fafb',
      padding: '32px 0'
    },
    wrapper: {
      maxWidth: '672px',
      margin: '0 auto',
      padding: '0 16px'
    },
    header: {
      textAlign: 'center',
      marginBottom: '32px'
    },
    title: {
      fontSize: '30px',
      fontWeight: 'bold',
      color: '#111827',
      marginBottom: '8px'
    },
    subtitle: {
      color: '#6b7280'
    },
    formCard: {
      backgroundColor: 'white',
      borderRadius: '12px',
      boxShadow: '0 1px 3px rgba(0, 0, 0, 0.1)',
      border: '1px solid #e5e7eb',
      padding: '32px'
    },
    form: {
      display: 'flex',
      flexDirection: 'column',
      gap: '24px'
    },
    label: {
      display: 'block',
      fontSize: '14px',
      fontWeight: '500',
      color: '#374151',
      marginBottom: '12px'
    },
    categoryGrid: {
      display: 'grid',
      gap: '12px'
    },
    categoryOption: {
      position: 'relative',
      display: 'flex',
      cursor: 'pointer',
      borderRadius: '8px',
      border: '1px solid #e5e7eb',
      padding: '16px',
      transition: 'all 0.2s'
    },
    categoryOptionSelected: {
      border: '1px solid #3b82f6',
      backgroundColor: '#eff6ff',
      boxShadow: '0 0 0 2px #3b82f6'
    },
    categoryOptionHover: {
      border: '1px solid #d1d5db',
      backgroundColor: '#f9fafb'
    },
    categoryContent: {
      flex: '1'
    },
    categoryHeader: {
      display: 'flex',
      alignItems: 'center'
    },
    categoryLabel: {
      fontSize: '18px',
      fontWeight: '500',
      color: '#111827'
    },
    categoryDescription: {
      fontSize: '14px',
      color: '#6b7280',
      marginTop: '4px'
    },
    checkIcon: {
      marginLeft: 'auto',
      height: '20px',
      width: '20px',
      color: '#2563eb'
    },
    input: {
      display: 'block',
      width: '100%',
      padding: '12px',
      border: '1px solid #d1d5db',
      borderRadius: '8px',
      fontSize: '14px',
      boxSizing: 'border-box',
      transition: 'border-color 0.2s'
    },
    inputFocus: {
      outline: 'none',
      border: '1px solid #3b82f6',
      boxShadow: '0 0 0 2px #3b82f6'
    },
    textarea: {
      display: 'block',
      width: '100%',
      padding: '12px',
      border: '1px solid #d1d5db',
      borderRadius: '8px',
      fontSize: '14px',
      boxSizing: 'border-box',
      resize: 'vertical',
      transition: 'border-color 0.2s',
      minHeight: '120px'
    },
    charCount: {
      fontSize: '12px',
      color: '#6b7280',
      marginTop: '4px'
    },
    buttonContainer: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      paddingTop: '16px',
      borderTop: '1px solid #e5e7eb'
    },
    cancelButton: {
      padding: '8px 16px',
      fontSize: '14px',
      fontWeight: '500',
      color: '#374151',
      backgroundColor: 'white',
      border: '1px solid #d1d5db',
      borderRadius: '8px',
      cursor: 'pointer',
      transition: 'background-color 0.2s'
    },
    cancelButtonHover: {
      backgroundColor: '#f9fafb'
    },
    submitButton: {
      padding: '8px 24px',
      fontSize: '14px',
      fontWeight: '500',
      borderRadius: '8px',
      border: 'none',
      cursor: 'pointer',
      transition: 'all 0.2s'
    },
    submitButtonEnabled: {
      backgroundColor: '#2563eb',
      color: 'white',
      boxShadow: '0 1px 3px rgba(0, 0, 0, 0.1)'
    },
    submitButtonEnabledHover: {
      backgroundColor: '#1d4ed8',
      boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)'
    },
    submitButtonDisabled: {
      backgroundColor: '#d1d5db',
      color: '#6b7280',
      cursor: 'not-allowed'
    },
    loadingSpinner: {
      display: 'flex',
      alignItems: 'center',
      gap: '8px'
    },
    spinner: {
      width: '16px',
      height: '16px',
      border: '2px solid white',
      borderTop: '2px solid transparent',
      borderRadius: '50%',
      animation: 'spin 1s linear infinite'
    },
    tipsSection: {
      marginTop: '32px',
      backgroundColor: '#eff6ff',
      border: '1px solid #bfdbfe',
      borderRadius: '8px',
      padding: '24px'
    },
    tipsTitle: {
      fontSize: '14px',
      fontWeight: '500',
      color: '#1e40af',
      marginBottom: '12px'
    },
    tipsList: {
      fontSize: '14px',
      color: '#1e3a8a',
      listStyle: 'none',
      padding: 0,
      margin: 0
    },
    tipsItem: {
      marginBottom: '4px'
    },
    hidden: {
      position: 'absolute',
      width: '1px',
      height: '1px',
      padding: 0,
      margin: '-1px',
      overflow: 'hidden',
      clip: 'rect(0, 0, 0, 0)',
      whiteSpace: 'nowrap',
      border: 0
    }
  };

  return (
    <>
      <Navbar />
      <div style={styles.container}>
        <div style={styles.wrapper}>
          {/* Header */}
          <div style={styles.header}>
            <h1 style={styles.title}>Submit Feedback</h1>
            <p style={styles.subtitle}>
              Share your ideas, report bugs, or suggest improvements to help us make the product better.
            </p>
          </div>

          {/* Form Card */}
          <div style={styles.formCard}>
            <form onSubmit={handleSubmit} style={styles.form}>
              {/* Category Selection */}
              <div>
                <label style={styles.label}>
                  What type of feedback is this? *
                </label>
                <div style={styles.categoryGrid}>
                  {categoryOptions.map((option) => (
                    <label
                      key={option.value}
                      style={{
                        ...styles.categoryOption,
                      }}
                      className={`
                        relative flex cursor-pointer rounded-lg border p-4 transition-all
                        ${formData.category === option.value 
                          ? 'border-blue-500 bg-blue-50 ring-2 ring-blue-500' 
                          : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                        }
                      `}
                    >
                      <input
                        type="radio"
                        name="category"
                        value={option.value}
                        checked={formData.category === option.value}
                        onChange={handleChange}
                        className="sr-only"
                      />
                      <div className="flex-1">
                        <div className="flex items-center">
                          <span className="text-lg font-medium text-gray-900">
                            {option.label}
                          </span>
                          {formData.category === option.value && (
                            <svg className="ml-auto h-5 w-5 text-blue-600" fill="currentColor" viewBox="0 0 20 20">
                              <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                            </svg>
                          )}
                        </div>
                        <p className="text-sm text-gray-500 mt-1">{option.description}</p>
                      </div>
                    </label>
                  ))}
                </div>
              </div>

              {/* Title Input */}
              <div>
                <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-2">
                  Title *
                </label>
                <input
                  id="title"
                  name="title"
                  type="text"
                  value={formData.title}
                  placeholder="Give your feedback a clear, descriptive title..."
                  className="block w-full px-3 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 placeholder-gray-500 transition-colors"
                  onChange={handleChange}
                  maxLength={100}
                />
                <p className="text-xs text-gray-500 mt-1">
                  {formData.title.length}/100 characters
                </p>
              </div>

              {/* Description Input */}
              <div>
                <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-2">
                  Description *
                </label>
                <textarea
                  id="description"
                  name="description"
                  rows={6}
                  value={formData.description}
                  placeholder="Provide details about your feedback. Include steps to reproduce for bugs, or explain the value of your feature request..."
                  className="block w-full px-3 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 placeholder-gray-500 transition-colors resize-vertical"
                  onChange={handleChange}
                  maxLength={1000}
                />
                <p className="text-xs text-gray-500 mt-1">
                  {formData.description.length}/1000 characters
                </p>
              </div>

              {/* Submit Button */}
              <div className="flex items-center justify-between pt-4 border-t border-gray-200">
                <button
                  type="button"
                  onClick={() => navigate(-1)}
                  className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting || !formData.title.trim() || !formData.description.trim()}
                  className={`
                    px-6 py-2 text-sm font-medium rounded-lg transition-all
                    ${isSubmitting || !formData.title.trim() || !formData.description.trim()
                      ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                      : 'bg-blue-600 hover:bg-blue-700 text-white shadow-sm hover:shadow'
                    }
                  `}
                >
                  {isSubmitting ? (
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      Submitting...
                    </div>
                  ) : (
                    'Submit Feedback'
                  )}
                </button>
              </div>
            </form>
          </div>

          {/* Tips Section */}
          <div className="mt-8 bg-blue-50 border border-blue-200 rounded-lg p-6">
            <h3 className="text-sm font-medium text-blue-900 mb-3">💡 Tips for great feedback</h3>
            <ul className="text-sm text-blue-800 space-y-1">
              <li>• Be specific and descriptive in your title</li>
              <li>• Include steps to reproduce for bugs</li>
              <li>• Explain the impact or value of feature requests</li>
              <li>• Check if similar feedback already exists</li>
            </ul>
          </div>
        </div>
      </div>
    </>
  );
};

export default Submit;